#include "LineCrossPromotion.h"

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)

#include <jni.h>
#include <android/log.h>
#include "platform/android/jni/JniHelper.h"

#define  LOG_TAG    "LINE_CROSSPROMOTION_LOG"
#define  LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)

#define  LINE_CROSSPROMOTION_PLUGIN_CLASS_NAME "com/line/crosspromotion/plugin/cocos2dx/LineCrossPromotionCocos2dxPlugin"

#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
#else
#define LOGD(...)

#endif

#if (CC_TARGET_PLATFORM == CC_PLATFORM_ANDROID)

typedef struct JniMethodInfo_
{
    JNIEnv *    env;
    jclass      classId;
    jmethodID   methodId;
} JniMethodInfo;

extern "C"
{
	static JNIEnv* getJNIEnv(void) {
		JavaVM* jvm = cocos2d::JniHelper::getJavaVM();
		if (NULL == jvm) {
			LOGD("Failed to get JNIEnv. JniHelper::getJavaVM() is NULL");
			return NULL;
		}

		JNIEnv *env = NULL;
		jint ret = jvm->GetEnv((void**)&env, JNI_VERSION_1_4);

		switch (ret) {
			case JNI_OK :
				return env;

			case JNI_EDETACHED :
				if (jvm->AttachCurrentThread(&env, NULL) < 0)
				{
					LOGD("Failed to get the environment using AttachCurrentThread()");
					return NULL;
				} else {
					return env;
				}

			case JNI_EVERSION :
				LOGD("JNI interface version 1.4 not supported");
			default :
				LOGD("Failed to get the environment using GetEnv()");
				return NULL;
		}
	}

	static bool getStaticMethodInfo(JniMethodInfo &methodinfo, const char *methodName, const char *methodSignature) {
		JNIEnv *pEnv = getJNIEnv();
	    if (!pEnv) {
	        return false;
	    }

	    jclass classId;

	    classId = pEnv->FindClass(LINE_CROSSPROMOTION_PLUGIN_CLASS_NAME);
		if (!classId) {
			LOGD("Failed to find class of %s", LINE_CROSSPROMOTION_PLUGIN_CLASS_NAME);
			return false;
		}

		jmethodID methodId = pEnv->GetStaticMethodID(classId, methodName, methodSignature);
		if (!methodId) {
			LOGD("Failed to find static method id of %s", methodName);
			pEnv->DeleteLocalRef(classId);
			return false;
		}

		methodinfo.env = pEnv;
		methodinfo.classId = classId;
		methodinfo.methodId = methodId;

		return true;
	}

	static void callStaticMethod(const char*methodName) {
		JniMethodInfo methodInfo;

		if (!getStaticMethodInfo(methodInfo, methodName, "()V")) {
			return;
		}

		methodInfo.env->CallStaticVoidMethod(methodInfo.classId, methodInfo.methodId);
		methodInfo.env->DeleteLocalRef(methodInfo.classId);
	}

	static void callStaticMethodWithStringParam(const char*methodName, const char* param) {
		JniMethodInfo methodInfo;

		if (!getStaticMethodInfo(methodInfo, methodName, "(Ljava/lang/String;)V")) {
			return;
		}

		jstring paramName = methodInfo.env->NewStringUTF(param);

		methodInfo.env->CallStaticVoidMethod(methodInfo.classId, methodInfo.methodId, paramName);
		methodInfo.env->DeleteLocalRef(paramName);
		methodInfo.env->DeleteLocalRef(methodInfo.classId);
	}

	void Java_com_line_crosspromotion_plugin_cocos2dx_LineCrossPromotionCocos2dxPlugin_sendCallbackMessageType1(JNIEnv *env, jobject thisObj, jint methodId, jstring param) {
		const char *pname = env->GetStringUTFChars(param, NULL);

		LineCrossPromotionCallbackListener *handler = LineCrossPromotion::getCallbackListener();

		if (handler != NULL) {
			switch(methodId) {
			case 3: // OnShowContentsSuccess
				handler->OnShowContentsSuccess(pname);
				break;
			case 5: // OnCloseContents
				handler->OnCloseContents(pname);
				break;
			case 6:
				handler->OnInitInterstitialAdSuccess();
				break;
			case 7:
				handler->OnInitInterstitialAdFailure(pname);
				break;
			case 8:
				handler->OnShowInterstitialAdSuccess(pname);
				break;
			case 10:
				handler->OnCloseInterstitialAd(pname);
				break;
			}
		}

		env->ReleaseStringUTFChars(param, pname);
	}

	void Java_com_line_crosspromotion_plugin_cocos2dx_LineCrossPromotionCocos2dxPlugin_sendCallbackMessageType2(JNIEnv *env, jobject thisObj, jint methodId,
			jstring param0, jint param1, jstring param2) {
		const char *pname = env->GetStringUTFChars(param0, NULL);
		const char *pmessage = env->GetStringUTFChars(param2, NULL);

		LineCrossPromotionCallbackListener *handler = LineCrossPromotion::getCallbackListener();

		if (handler != NULL) {
			switch(methodId) {
			case 2: // OnGetContentsFailure
				handler->OnGetContentsFailure(pname, param1, pmessage);
				break;
			case 4: // OnShowContentsFailure
				handler->OnShowContentsFailure(pname, param1, pmessage);
				break;
			}
		}
		env->ReleaseStringUTFChars(param0, pname);
		env->ReleaseStringUTFChars(param2, pmessage);

	}

	void Java_com_line_crosspromotion_plugin_cocos2dx_LineCrossPromotionCocos2dxPlugin_sendCallbackMessageType3(JNIEnv *env, jobject thisObj, jint methodId,
			jstring param0, jint param1, jint param2) {
		const char *pname = env->GetStringUTFChars(param0, NULL);

		LineCrossPromotionCallbackListener *handler = LineCrossPromotion::getCallbackListener();

		if (handler != NULL) {
			switch(methodId) {
			case 1: // OnGetContentsSuccess
				handler->OnGetContentsSuccess(pname, param1, param2);
				break;
			}
		}
		env->ReleaseStringUTFChars(param0, pname);
	}

	void Java_com_line_crosspromotion_plugin_cocos2dx_LineCrossPromotionCocos2dxPlugin_sendCallbackMessageType4(JNIEnv *env, jobject thisObj, jint methodId,
			jstring param0, jstring param1) {
		const char *pname = env->GetStringUTFChars(param0, NULL);
		const char *pmessage = env->GetStringUTFChars(param1, NULL);

		LineCrossPromotionCallbackListener *handler = LineCrossPromotion::getCallbackListener();

		if (handler != NULL) {
			switch(methodId) {
			case 9:
				handler->OnShowInterstitialAdFailure(pname, pmessage);
				break;
			}
		}
		env->ReleaseStringUTFChars(param0, pname);
		env->ReleaseStringUTFChars(param1, pmessage);
	}

} // extern "C"

// ADBRIX API
void LineCrossPromotion::startApplication(){
	callStaticMethod("startApplication");
}

void LineCrossPromotion::setUserId(const char* userId){
	callStaticMethodWithStringParam("setUserId", userId);
}

void LineCrossPromotion::startSession(){
	callStaticMethod("startSession");
}

void LineCrossPromotion::endSession(){
	callStaticMethod("endSession");
}

void LineCrossPromotion::unlock(Event event){
	const char* event_str = NULL;
	if(event == Event::SIGN_IN) event_str = "igaw_cp_signin";
	if(event == Event::SIGN_UP) event_str = "igaw_cp_signup";
	callStaticMethodWithStringParam("unlock", event_str);
}

void LineCrossPromotion::initInterstitialAd(){
	callStaticMethod("initInterstitialAd");
}

void LineCrossPromotion::showInterstitialAd(const char* adSpotKey){
	callStaticMethodWithStringParam("showInterstitialAd", adSpotKey);
}
// ADPOPCORN API
void LineCrossPromotion::getOfferwall(const char* adSpotKey) {
	callStaticMethodWithStringParam("getOfferwall", adSpotKey);
}

void LineCrossPromotion::showOfferwall(const char* adSpotKey) {
	callStaticMethodWithStringParam("showOfferwall", adSpotKey);
}

void LineCrossPromotion::setLanguage(const char* language) {
	callStaticMethodWithStringParam("setLanguage", language);
}

#elif (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
}

#else

#endif

LineCrossPromotionCallbackListener *LineCrossPromotion::callbackListener = NULL;

void LineCrossPromotion::setCallbackListener(LineCrossPromotionCallbackListener *listener) {
	callbackListener = listener;
}

LineCrossPromotionCallbackListener *LineCrossPromotion::getCallbackListener() {
	return callbackListener;
}

const char* LineCrossPromotion::LANGUAGE::KOREAN = "ko";
const char* LineCrossPromotion::LANGUAGE::JAPANESE = "ja";
const char* LineCrossPromotion::LANGUAGE::CHINESE_CN = "zh_cn";
const char* LineCrossPromotion::LANGUAGE::CHINESE_TW = "zh_tw";
const char* LineCrossPromotion::LANGUAGE::ENGLISH = "en";