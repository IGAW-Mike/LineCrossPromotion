#ifndef __LINE_CROSSPROMOTION_H__
#define __LINE_CROSSPROMOTION_H__

#include "cocos2d.h"

class LineCrossPromotionCallbackListener {
public:
	// INTERSTITIAL CALLBACK
	virtual void OnInitInterstitialAdFailure(const char* errorMessage){}
	virtual void OnInitInterstitialAdSuccess(){}
	virtual void OnCloseInterstitialAd(const char* adSpotKey){}
	virtual void OnShowInterstitialAdFailure(const char* adSpotKey, const char* errorMessage){}
	virtual void OnShowInterstitialAdSuccess(const char* adSpotKey){}
	// OFFERWALL CALLBACK
	virtual void OnGetContentsSuccess(const char*  adSpotKey, int contentsType, int adType){}
	virtual void OnGetContentsFailure(const char*  adSpotKey, int errorCode, const char* errorMessage){}
	virtual void OnShowContentsSuccess(const char*  adSpotKey){}
	virtual void OnShowContentsFailure(const char*  adSpotKey, int errorCode, const char* errorMessage){}
	virtual void OnCloseContents(const char*  adSpotKey){}

	virtual ~LineCrossPromotionCallbackListener() {}
};

class LineCrossPromotion {
private:
	static LineCrossPromotionCallbackListener* callbackListener;

public:
	enum Event {
		SIGN_UP, SIGN_IN
	};
	class LANGUAGE{
	public:
		static const char* KOREAN;
		static const char* JAPANESE;
		static const char* CHINESE_CN;
		static const char* CHINESE_TW;
		static const char* ENGLISH;
	};

	static void setCallbackListener(LineCrossPromotionCallbackListener *callbackListener);
	static LineCrossPromotionCallbackListener *getCallbackListener();

	static void startApplication();
	static void startSession();
	static void endSession();
	static void setUserId(const char* userId);
	static void unlock(Event name);
	static void initInterstitialAd();
	static void showInterstitialAd(const char* adSpotKey);

	static void getOfferwall(const char* adSpotKey);
	static void showOfferwall(const char* adSpotKey);
	static void setLanguage(const char* language);
};

#endif // __LINE_CROSSPROMOTION_H__
