//
//  PluginLineCrossPromotionSDK.h
//  PluginLineCrossPromotionSDK
//
//  Created by wonje,song on 2016. 4. 19..
//  Copyright © 2016년 wonje,song. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "InterfaceAds.h"

@interface PluginLineCrossPromotionSDK : NSObject <InterfaceAds>

/*!
 @abstract
 init.
 
 @discussion
 init
 
 @param appKey            app key
 @param hashKey           hash key
 */
- (void)initCrossPromotionWithAppKey:(NSMutableDictionary *)params;


/*!
 @abstract
 로그를 level를 설정한다.
 
 @discussion
 보고자 하는 로그 level을 info, debug, trace으로 설정한다.
 
 @param LogLevel            log level
 logLevel : 0 (LineCrossPromotionSDKLogInfo), 1(LineCrossPromotionSDKLogDebug), 2(LineCrossPromotionSDKLogTrace)
 
 */
- (void)setLogLevel:(NSNumber *)logLevel;


/*!
 @abstract
 사용자의 user id를 전송하고자 할때 호출한다.
 
 @param userId              user id.
 */

- (void)setUserId:(NSString *)userId;



/*!
 @abstract
 set language
 
 @discussion
 [language designator]-[script designator] 의 포멧으로 설정한다.
 https://developer.apple.com/library/ios/documentation/MacOSX/Conceptual/BPInternational/LanguageandLocaleIDs/LanguageandLocaleIDs.html
 "ko",
 "zh-Hans",
 "zh-Hant",
 "zh-HK",
 "ja"
 */
- (void)setLanguage:(NSString *)language;

/*!
 @abstract
 Unlock activity event : SIGN_UP, SIGN_IN
 event : 0 (SIGN_UP), 1(SIGN_IN)
 */
- (void)unlock:(NSNumber *)event;

/*!
 @abstract
 Get offerwall
 
 @discussion
 Get offerwall
 
 @param spotKey                    spot key
 @param userDataDictionaryForFilter     filtering(targeting)을 위한 user data
 */
- (void)getOfferwall:(NSDictionary *)params;


- (BOOL)isOfferwallAvailable;

/*!
 @abstract
 Show offerwall
 
 @discussion
 Show offerwall
 */
- (void)showOfferwall;

/*!
 @abstract
 Show interstitial
 
 @discussion
 Show interstitial
 
 @param space key                         space key

 */
- (void)showInterstitial:(NSString *)spaceKey;

/*!
 @abstract
 Set offerwall delegate
 
 */
- (void)setOfferwallDelegate;


/*!
 @abstract
 Set interstitial ad delegate
 
 */
- (void)setInterstitialAdDelegate;

@end
