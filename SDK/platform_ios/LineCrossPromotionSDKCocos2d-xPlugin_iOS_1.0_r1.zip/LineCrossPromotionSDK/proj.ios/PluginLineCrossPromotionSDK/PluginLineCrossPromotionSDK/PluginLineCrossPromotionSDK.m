//
//  PluginLineCrossPromotionSDK.m
//  PluginLineCrossPromotionSDK
//
//  Created by wonje,song on 2016. 4. 19..
//  Copyright © 2016년 wonje,song. All rights reserved.
//

#import "PluginLineCrossPromotionSDK.h"

#import "AdsWrapper.h"

#import <LineCrossPromotionSDK/LineCrossPromotionSDK.h>

@interface PluginLineCrossPromotionSDK () <LineCrossPromotionSDKOfferwallDelegate, LineCrossPromotionSDKInterstitialAdDelegate>

@end

@implementation PluginLineCrossPromotionSDK

- (void)initCrossPromotionWithAppKey:(NSMutableDictionary *)params
{
    [LineCrossPromotionSDK initCrossPromotionWithAppKey:[self checkNilToBlankString:[params objectForKey:@"Param1"]] andHashKey:[self checkNilToBlankString:[params objectForKey:@"Param2"]]];
}

- (void)setLogLevel:(NSNumber *)logLevel
{
    [LineCrossPromotionSDK setLogLevel:[self checkNilToZero:logLevel]];
}

- (void)setUserId:(NSString *)userId
{
    [LineCrossPromotionSDK setUserId:[self checkNilToBlankString:userId]];
}

- (void)setLanguage:(NSString *)language
{
    [LineCrossPromotionSDK setLanguage:[self checkNilToBlankString:language]];
}

- (void)unlock:(NSNumber *)event
{
    [LineCrossPromotionSDK unlock:[self checkNilToZero:event]];
}

- (void)getOfferwall:(NSDictionary *)params
{
    NSLog(@"plugin : getOfferwall : params : %@", params);
    
    if ([params isKindOfClass:[NSString class]]) {
        NSLog(@"NSString params : %@", params);
        
        [LineCrossPromotionSDK getOfferwall:(NSString *)params userDataDictionaryForFilter:nil];
        
    } else if ([params isKindOfClass:[NSDictionary class]]) {
        NSLog(@"NSDictionary params : %@", params);
        
        NSMutableDictionary *userDataDictionaryForFilter = [self checkNilToNil:[params objectForKey:@"Param2"]];
        
        [LineCrossPromotionSDK getOfferwall:[self checkNilToBlankString:[params objectForKey:@"Param1"]]  userDataDictionaryForFilter:userDataDictionaryForFilter];
    }
}

- (BOOL)isOfferwallAvailable
{
    NSLog(@"plugin isOfferwallAvailable : %d", [LineCrossPromotionSDK shared].isOfferwallAvailable);
    
    return [LineCrossPromotionSDK shared].isOfferwallAvailable;
}

- (void)showOfferwall
{
    [LineCrossPromotionSDK showOfferwall:[AdsWrapper getCurrentRootViewController]];
}

- (void)showInterstitial:(NSString *)spaceKey
{
    [LineCrossPromotionSDK showInterstitial:[self checkNilToBlankString:spaceKey] viewController:[AdsWrapper getCurrentRootViewController]];
}

- (void)setOfferwallDelegate
{
    [LineCrossPromotionSDK shared].offerwallDelegate = self;
}

- (void)setInterstitialAdDelegate
{
    
    [LineCrossPromotionSDK shared].interstitialAdDelegate = self;
    
    NSLog(@"plugin : setInterstitialAdDelegate : %@", [LineCrossPromotionSDK shared].interstitialAdDelegate);
}


#pragma mark - InterfaceAds
- (void)configDeveloperInfo:(NSMutableDictionary *)devInfo
{
    // no-op
}

- (void)showAds:(NSMutableDictionary *)info position:(int)pos
{
    // no-op
}

- (void)hideAds:(NSMutableDictionary *)info
{
    // no-op
}

- (void)queryPoints
{
    // no-op
}

- (void)spendPoints:(int)points
{
    // no-op
}

- (void)setDebugMode:(BOOL)debug
{
    // no-op
}

- (NSString *)getSDKVersion
{
    return @"1.0.0mi";
}

- (NSString *)getPluginVersion
{
    return @"1.0";
}

#pragma mark - LineCrossPromotionSDKOfferwallDelegate
- (void)getOfferwallDidComplete
{
    [AdsWrapper onAdsResult:self withRet:kAdsReceived withMsg:@"getOfferwallDidComplete"];
}

- (void)getOfferwallDidFailWithError:(NSError *)error
{
    
    [AdsWrapper onAdsResult:self withRet:kUnknownError withMsg:[NSString stringWithFormat:@"getOfferwallDidFailWithError?error=%@", error.description]];
}

- (void)offerwallWillOpen
{
    [AdsWrapper onAdsResult:self withRet:kAdsReceived withMsg:@"offerwallWillOpen"];
}

- (void)offerwallDidOpen
{
    [AdsWrapper onAdsResult:self withRet:kAdsShown withMsg:@"offerwallDidOpen"];
}

- (void)offerwallWillClose
{
    [AdsWrapper onAdsResult:self withRet:kAdsReceived withMsg:@"offerwallWillClose"];
}

- (void)offerwallDidClose
{
    [AdsWrapper onAdsResult:self withRet:kAdsDismissed withMsg:@"offerwallDidClose"];
}

#pragma mark - LineCrossPromotionSDKInterstitialAdDelegate
- (void)interstitialAdWillLoad
{
    NSLog(@"plugin : interstitialAdWillLoad");
    
    [AdsWrapper onAdsResult:self withRet:kAdsReceived withMsg:@"interstitialAdWillLoad"];
}

- (void)interstitialAdDidLoad
{
    [AdsWrapper onAdsResult:self withRet:kAdsShown withMsg:@"interstitialAdDidLoad"];
}

- (void)interstitialAdDidUnload
{
    [AdsWrapper onAdsResult:self withRet:kAdsDismissed withMsg:@"interstitialAdDidUnload"];
}

- (void)willLeaveApplicationByInterstitialAd
{
    [AdsWrapper onAdsResult:self withRet:kAdsReceived withMsg:@"willLeaveApplicationByInterstitialAd"];
}

- (void)interstitialAdDidFailWithError:(NSError *)error
{
    [AdsWrapper onAdsResult:self withRet:kUnknownError withMsg:[NSString stringWithFormat:@"interstitialAdDidFailWithError?error=%@", error.description]];
}


#pragma mark - private method
- (NSString *)checkNilToBlankString:(id)target
{
    NSString *returnString = @"";
    if ([NSNumber numberWithInt:0] != target)
    {
        returnString = target;
    }
    
    return returnString;
}

- (BOOL)checkNilToNo:(id)target
{
    BOOL returnBool = NO;
    if ([NSNumber numberWithInt:0] != target)
    {
        returnBool = (BOOL)[target boolValue];
    }
    
    return returnBool;
}

- (int)checkNilToZero:(id)target
{
    int returnInt = 0;
    if ([NSNumber numberWithInt:0] != target)
    {
        returnInt = [target intValue];
    }
    
    return returnInt;
}

- (NSInteger)checkIntegerNilToZero:(id)target
{
    NSInteger returnInteger = 0;
    if (!([target isEqual:[NSNull null]] || target == nil))
    {
        returnInteger = [target integerValue];
    }
    
    return returnInteger;
}

- (id)checkNilToNil:(id)target
{
    id returnObject = nil;
    if ([NSNumber numberWithInt:0] != target)
    {
        returnObject = target;
    }
    
    return returnObject;
    
}

- (double)checkNilToDoubleZero:(id)target
{
    double returnDouble = 0.0;
    if ([NSNumber numberWithDouble:0.0] != target)
    {
        returnDouble = [target doubleValue];
    }
    
    return returnDouble;
}

@end
