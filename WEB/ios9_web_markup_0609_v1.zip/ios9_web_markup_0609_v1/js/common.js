$(function () {
	function setValue(lang){
		lang = lang == undefined ? "" : lang;
		
		if( lang.indexOf("ko") >= 0 ){
			lang = "_kr"
		}else if( lang.indexOf("ja") >= 0 || lang.indexOf("jp") >= 0 ){
			lang = "_jp"
		}else if( lang.indexOf("cn") >= 0 ){
			lang = "_cn"
		}else if( lang.indexOf("tw") >= 0 ){
			lang = "_tw"
		}else{
			lang = "";
		}
		return lang;
	}

	var Init = function Init(lang){
		//console.log("default : " + lang)
		//Set language Value
		lang = setValue(lang);
		//console.log("set value : " + lang);
	
		var text = "<p>If the app is already installed, please be sure to participate via the PLAY GAME AND GET ITEM button. </p><p>Rewards may not be distributed if you participate via other means.</p>";
		var text_jp = "<p>すでに対象のアプリがインストールされている場合、必ずPLAY GAME AND GET ITEMボタンより参加してください。</p><p>正常にエントリーとならない可能性があり、Rewardが支給されない場合があります。</p>";
		var text_kr = "<p>이미 대상 앱을 설치한 분께서는 PLAY GAME AND GET ITEM 버튼을 눌러 참여해 주시기 바랍니다. </p><p>해당 버튼을 통해 참여하셔야 Reward를 받으실 수 있습니다. </p>";
		var text_cn = "<p>如果您已安装指定应用，请点击“PLAY GAME AND GET ITEM”来参加活动。</p><p>未点击可能无法正常获得奖励，请留意。</p>";
		var text_tw = "<p>若您已安裝對象應用程式，請點選「PLAY GAME AND GET ITEM」來參加活動。</p><p>未點選可能無法正常獲得獎勵，敬請留意。</p>";
		var note_text = eval("text"+lang);
		
		var title_src = "img/install-title" + lang + ".png";
		var area_src = "img/install-btn" + lang + ".png";
		var note_src = "img/notes-title" + lang + ".png";
		
		//Init img-src & note_text
		$('.install-title img').attr('src',title_src);
		$('.install-area img').attr('src',area_src);
		$('.notes-title img').attr('src',note_src);
		$('.notes-text').html(note_text);
	}
	
	//language Init
	Init(navigator.language);
});